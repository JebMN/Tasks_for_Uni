class Exercise1 {
    public static void main(String [] args) {
        int sum = add(7,8);
        System.out.println("Here is the sum of the two numbers : " + sum);
    }
    public static int add(int a, int b) {
        return a + b;
    }
}