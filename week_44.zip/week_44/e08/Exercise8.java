public class Exercise8 {
    public static void main(final String[] args) {
        
        Calculator calc = new Calculator();
        calc.addAndDisplay(10, 15); 
    }
}