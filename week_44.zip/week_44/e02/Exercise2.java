class Exercise2 {
    public static void main(String [] args) {
        greet("Alice");
    
    }

    public static void greet(String name) {
        System.out.println("Hello " + name + "!");  
    }
}