public class Parent {
    protected void showMessage() {
        System.out.println("Message from Parent class");
    }
}