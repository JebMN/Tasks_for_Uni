public class Child extends Parent {
    public void callParentMessage() {
        showMessage();
    }
}